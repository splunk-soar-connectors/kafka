from __future__ import absolute_import

import sys

from kafka.cli.consumer import run_cli

sys.exit(run_cli())
