import sys

print("Available module interfaces: kafka.consumer, kafka.producer, kafka.admin")

sys.exit(1)
